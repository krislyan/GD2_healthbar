﻿using UnityEngine;

public class Player : MonoBehaviour
{
    public int maxHealth = 100;
    public int currentHealth;

    // Ссылка на наш скрипт HealthBar, чтобы обновлять полоску на экране
    public HealthBar healthBar;

    void Start()
    {
        // ВРЕМЕННО: ставим 20 ХП на старте для теста хила
        currentHealth = 20;

        if (healthBar != null)
        {
            healthBar.SetMaxHealth(maxHealth); // Максимум останется 100
            healthBar.SetHealth(currentHealth); // Но полоска съедет на 20!
        }
    }

    // Метод для получения урона (чтобы проверить, как тратится ХП)
    public void TakeDamage(int damage)
    {
        currentHealth -= damage;
        if (currentHealth < 0) currentHealth = 0;

        if (healthBar != null)
        {
            healthBar.SetHealth(currentHealth);
        }
    }

    // Тот самый метод лечения, который вызывает наша зелёная сфера!
    public void Heal(int healAmount)
    {
        currentHealth += healAmount;

        if (currentHealth > maxHealth)
        {
            currentHealth = maxHealth;
        }

        if (healthBar != null)
        {
            healthBar.SetHealth(currentHealth);
        }
    }
}