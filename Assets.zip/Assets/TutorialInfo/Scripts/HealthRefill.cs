﻿using UnityEngine;

public class HealthRefillZone : MonoBehaviour
{
    // Скорость лечения. По дефолту ставим 1 ХП за кадр, пока игрок в зоне
    [SerializeField] private int healSpeed = 1;

    // Этот метод срабатывает автоматически, пока игрок стоит внутри триггера
    private void OnTriggerStay(Collider other)
    {
        // Проверяем по тегу, что в зону зашел именно игрок
        if (other.CompareTag("Player"))
        {
            // Берем скрипт Player у нашего игрока
            Player player = other.GetComponent<Player>();

            if (player != null)
            {
                // Вызываем метод лечения из скрипта Player!
                player.Heal(healSpeed);
            }
        }
    }
}