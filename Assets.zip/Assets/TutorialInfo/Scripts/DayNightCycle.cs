﻿using UnityEngine;

public class DayNightCycle : MonoBehaviour
{
    // Теперь ровно 1.2f для 5-минутного цикла
    private float daySpeed = 1.2f;

    void Update()
    {
        transform.Rotate(Vector3.right * daySpeed * Time.deltaTime);
    }
}