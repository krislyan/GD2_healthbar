using UnityEngine;
using UnityEngine.UI;
using TMPro;

public class HealthBar : MonoBehaviour
{
    public Slider slider;
    public TMP_Text hpText;

    public void SetMaxHealth(int health)
    {
        slider.maxValue = health;
        slider.value = health;
        hpText.text = health + " / " + health;
    }

    public void SetHealth(int health)
    {
        slider.value = health;
        hpText.text = health + " / " + slider.maxValue;
    }
}