using UnityEngine;
using UnityEngine.UI;
using TMPro; // Эта строчка позволяет коду видеть красивый TextMeshPro

public class HealthBar : MonoBehaviour
{
    public Slider slider;
    
    // МЫ ЗАМЕНИЛИ "Text" НА "TMP_Text". Теперь сюда точно перетащится твой текст!
    public TMP_Text hpText; 

    public void SetMaxHealth(int health)
    {
        slider.maxValue = health;
        slider.value = health;
        hpText.text = health + " / " + health;
    }

    public void SetHealth(int health)
    {
        slider.value = health;
        hpText.text = health + " / " + slider.maxValue;
    }
}